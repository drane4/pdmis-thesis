<?php
$conn = new mysqli("localhost", "root", "", "pdmis") or die(mysqli_error()); 
?>